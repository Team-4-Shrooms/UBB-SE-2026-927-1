using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MovieApp.Logic.Models;

namespace MovieApp.Logic.Interfaces.Services
{
    interface IProfileService
    {
        Task<UserProfile> BuildProfileFromInteractionsAsync(int userId);
    }
}
