using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MovieApp.Logic.Interfaces.Repositories;
using MovieApp.Logic.Models;

namespace MovieApp.Logic.Services
{
    class InventoryService
    {
        private readonly IInventoryRepository _inventoryRepo;
        private readonly IUserRepository _userRepo;
        private readonly IMovieRepository _movieRepo;
        private readonly IEventRepository _eventRepo;

        public InventoryService(IInventoryRepository inventoryRepo, IUserRepository userRepo, IMovieRepository movieRepo, IEventRepository eventRepo)
        {
            _inventoryRepo = inventoryRepo;
            _userRepo = userRepo;
            _movieRepo = movieRepo;
            _eventRepo = eventRepo;
        }

        public async Task RemoveOwnedMovieAsync(int userId, int movieId)
        {
            var user = await _userRepo.GetUserByIdAsync(userId) ?? throw new KeyNotFoundException("User not found.");
            var movie = await _movieRepo.GetMovieByIdAsync(movieId);
            var ownerships = await _inventoryRepo.GetMovieOwnershipsAsync(userId, movieId);

            _inventoryRepo.RemoveMovieOwnerships(ownerships);

            await _inventoryRepo.AddTransactionAsync(new Transaction
            {
                Buyer = user,
                Movie = movie,
                Amount = 0m,
                Type = "RemoveOwnedMovie",
                Status = "Completed",
                Timestamp = DateTime.UtcNow
            });

            await _inventoryRepo.SaveChangesAsync();
        }

        public async Task RemoveOwnedTicketAsync(int userId, int eventId)
        {
            if (userId <= 0) return;

            User? user = await _userRepo.GetUserByIdAsync(userId);
            if (user is null) return;

            MovieEvent? movieEvent = await _eventRepo.GetEventByIdAsync(eventId);

            var ownerships = await _inventoryRepo.GetTicketOwnershipsAsync(userId, eventId);

            _inventoryRepo.RemoveTicketOwnerships(ownerships);

            Transaction transaction = new Transaction
            {
                Buyer = user,
                Event = movieEvent,
                Amount = 0m,
                Type = "RemoveOwnedTicket", // From RemoveOwnedTicketTransactionType
                Status = "Completed",       // From CompletedTransactionStatus
                Timestamp = DateTime.UtcNow
            };

            await _inventoryRepo.AddTransactionAsync(transaction);

            await _inventoryRepo.SaveChangesAsync();
        }
    }
}
